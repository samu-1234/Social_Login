import { SocialLoginData } from "./reducer";
import { combineReducers } from 'redux'
export default combineReducers({
    SocialLoginData,
    
})